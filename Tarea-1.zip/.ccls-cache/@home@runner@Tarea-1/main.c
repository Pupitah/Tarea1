#include "tdas/list.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

typedef struct{
  int hora;
  int minuto;
  int segundo;
} llegada;

typedef struct{
    char nombre[50];
    int edad;
    char sintoma[50];
    char prioridad[40];
    llegada lugar;
} tipoPaciente;


// Función para limpiar la pantalla
void limpiarPantalla() { system("clear"); }

// Menú principal
void mostrarMenuPrincipal() 
{
  puts("========================================");
  puts("     Sistema de Gestión Hospitalaria");
  puts("========================================");

  puts("1) Registrar paciente");
  puts("2) Asignar prioridad a paciente");
  puts("3) Mostrar lista de espera");
  puts("4) Atender al siguiente paciente");
  puts("5) Mostrar pacientes por prioridad");
  puts("6) Salir\n");
}

void mostrarPaciente(tipoPaciente *paciente)
{
  printf("Nombre del paciente: %s\n", paciente->nombre);
  printf("Edad: %d\n", paciente->edad);
  printf("Sintoma: %s\n", paciente->sintoma);
  printf("Hora de llegada: %d:%d:%d\n", paciente->lugar.hora, paciente->lugar.minuto, paciente->lugar.segundo);
  printf("Prioridad %s\n\n", paciente->prioridad);
}

void registrarPaciente(List *listaEspera)
{
  tipoPaciente *paciente = (tipoPaciente *)malloc(sizeof(tipoPaciente));
  strcpy(paciente->prioridad, "baja");
  printf("\nIngrese el nombre del paciente:");
  scanf(" %[^\n]50s", paciente->nombre);
  printf("\nIngrese la edad del paciente:");
  scanf(" %d", &paciente->edad);
  printf("\nIngrese síntoma del paciente:");
  scanf(" %[^\n]50s", paciente->sintoma);
  
  time_t tiempo_actual = time(NULL);
  struct tm *hora_local = localtime(&tiempo_actual);
  if (hora_local->tm_hour <= 4){
    paciente->lugar.hora = hora_local->tm_hour + 20;
  } else {paciente->lugar.hora = hora_local->tm_hour - 4;}
  
  paciente->lugar.minuto = hora_local->tm_min;
  paciente->lugar.segundo = hora_local->tm_sec;
  
  printf("\nPaciente registrado:\n");
  mostrarPaciente(paciente);
  list_pushBack(listaEspera, paciente);
}

int cmp(void *dato1, void *dato2){
  tipoPaciente *paciente1 = (tipoPaciente *)dato1;
  tipoPaciente *paciente2 = (tipoPaciente *)dato2;
  
  int prioridad1, prioridad2;  
  if(strcmp(paciente1->prioridad,"alta")== 0){
    prioridad1 = 3;
  }
  else if(strcmp(paciente1->prioridad,"media")== 0){
    prioridad1 = 2;
  }
  else if(strcmp(paciente1->prioridad,"baja")== 0){
    prioridad1 = 1;
  }
  if(strcmp(paciente2->prioridad,"alta")== 0){
    prioridad2 = 3;
  }
  else if(strcmp(paciente2->prioridad,"media")== 0){
    prioridad2 = 2;
  }
  else if(strcmp(paciente2->prioridad,"baja")== 0){
    prioridad2 = 1;
  }
  if(prioridad1 != prioridad2){
    return prioridad1 > prioridad2;
  }
  if (paciente1->lugar.hora != paciente2->lugar.hora) {
      return paciente1->lugar.hora < paciente2->lugar.hora;
  } 
  else if (paciente1->lugar.minuto != paciente2->lugar.minuto) {
    return paciente1->lugar.minuto < paciente2->lugar.minuto;
  } 
  else {
    return paciente1->lugar.segundo < paciente2->lugar.segundo;
  }
}

void asignarPrioridad(List *listaEspera, char *nombre)
{
  tipoPaciente *paciente = list_first(listaEspera);
  while (paciente != NULL)
    {
      char prioridad[6];
      if (strcmp(paciente->nombre, nombre) == 0){
        printf("Paciente encontrado\n");
        printf("Prioridad a asignar (por favor ingresar en minúsculas):");
        scanf(" %s", prioridad);
        strcpy(paciente->prioridad, prioridad);
        printf("Prioridad asignada al paciente\n\n");
        mostrarPaciente(paciente);
        list_popCurrent(listaEspera);
        list_sortedInsert(listaEspera,paciente,cmp);
        return;
      }
      paciente = list_next(listaEspera);
    }
  printf("Paciente no ingresado en la Lista\n\n");
}

void mostrarListaEspera(List *listaEspera ){
  tipoPaciente *paciente = list_first(listaEspera);
  printf("\nLista de Pacientes:\n");
  while(paciente != NULL){
    mostrarPaciente(paciente);
    paciente = list_next(listaEspera);
  }
}

int len(List *lista){
  int cont = 0;
  tipoPaciente *paciente = list_first(lista);
  while (paciente != NULL) {
    cont ++;
    paciente = list_next(lista);
  }
  return cont;
}

void atenderSiguientePaciente(List *listaEspera){
  int tamano = len(listaEspera);
  if (tamano == 0){
    printf("\nNo hay pacientes en la lista\n\n");         
    return;}
  
  tipoPaciente *paciente = list_first(listaEspera);
  printf("PACIENTE A ATENDER:\n");
  mostrarPaciente(paciente);
  list_popFront(listaEspera);
  
  if (tamano == 0){printf("\nNo hay pacientes en la lista\n\n");
  } else
  { tamano -=1;
    printf("Pacientes restantes: %d\n\n", tamano);}

}

void mostrarPacientesPorPrioridad(List *listaEspera){
  int contador = 0;
  char prioridad[6];
  printf("Ingrese prioridad deseada (en minúsculas):\n");
  scanf(" %s", prioridad);
  tipoPaciente *paciente = list_first(listaEspera);
  while (paciente != NULL)
  {
    if(strcmp(paciente->prioridad, prioridad) == 0){
      contador = 1;
      mostrarPaciente(paciente);
    }
  paciente = list_next(listaEspera);
  }
  if (contador == 0)
  {
    printf("\nNo hay pacientes con esa prioridad\n\n");
  }
}

int main() {
  char opcion;
  List *pacientes = list_create(); // puedes usar una lista para gestionar los pacientes
  
  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: ");
    scanf(" %c", &opcion); // Nota el espacio antes de %c para consumir el
                           // newline anterior

    switch (opcion) {
    case '1':
      registrarPaciente(pacientes);
      break;
    case '2':
      printf("Ingresa nombre a buscar:\n");
      char nombre[50];
      scanf("%s", nombre);
      asignarPrioridad(pacientes, nombre);
      break;
    case '3':
      mostrarListaEspera(pacientes);
      break;
    case '4':
      atenderSiguientePaciente(pacientes);
      break;
    case '5':
      mostrarPacientesPorPrioridad(pacientes);
      break;
    case '6':
      puts("Saliendo del sistema de gestión hospitalaria...");
      break;
    default:
      puts("Opción no válida. Por favor, intente de nuevo.");
    }
  

  } while (opcion != '6');
  
  list_clean(pacientes);

  return 0;
}



